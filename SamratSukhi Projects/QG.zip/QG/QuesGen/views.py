from django.shortcuts import render
from django.http import HttpResponse
from fpdf import FPDF 
from .apps import *
import os

def submit(request,id,t):
    U=CU.UL[id]
    U.ans.append(0)
    U.time=t#list(map(int,t.split(":")))
    skp=0
    wr=0
    rt=0
    for i in range(len(U.actans)):
        if str(U.ans[i])=="0":
            skp=skp+1
        else:
            if str(U.ans[i])==str(U.actans[i]):
                rt=rt+1
            else:
                wr=wr+1
    pdf=FPDF()

    pdf.add_page()
    pdf.set_text_color(109,15,128)    
    pdf.set_font("Arial",size=25)
    pdf.image('./QuesGen/static/Logo.png',90,10,30,30)
    pdf.cell(190, 80, txt = "QuesGen", ln = 2, align = 'C') 
    pdf.set_text_color(0,0,0)    
    pdf.cell(0, 0, txt = "<<< TEST CERTIFICATE >>>", ln = 2, align = 'C') 
    pdf.cell(100, 20, txt = "", ln=2, align = 'C') 

    pdf.set_font("Arial",size=15)
    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 20, txt = "Name:",  align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 20, txt =U.name,ln=1,  align = 'L') 

    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 0, txt = "Time:", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 0, txt = str(U.fintime)+" Minute",ln=1, align = 'L') 


    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 20, txt = "Time Left:", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 20, txt = t, ln=1, align = 'L') 


    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 0, txt = "Total Attempt:", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 0, txt = str(len(U.Question)), ln=1, align = 'L') 


    pdf.set_text_color(0,0,0) 
    pdf.cell(82, 20, txt = "Total Score:", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 20, txt = str(rt), ln=1, align = 'L') 
    

    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 0, txt = "Wrong :", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 0, txt = str(wr), ln=1, align = 'L') 
 
    pdf.set_text_color(0,0,0)   
    pdf.cell(82, 20, txt = "Not Answered:", align = 'R') 
    pdf.set_text_color(60,60,60)   
    pdf.cell(82, 20, txt = str(skp), ln=1, align = 'L') 
    


    pdf.add_page()
    pdf.set_text_color(109,15,128)    
    pdf.set_font("Arial",size=25)
    pdf.cell(190, 20, txt = "Questions", ln = 2, align = 'C') 
    pdf.set_font("Arial",size=13)
    pdf.set_text_color(0,0,0)    

    for i in range(len(U.Question)):
        pdf.set_text_color(0,0,0)    
        pdf.set_font("Arial",size=13)
        pdf.cell(190, 10, txt = "Questions "+str(i+1)+":"+U.Question[i].Q, ln = 1, align = 'L') 

        imm=str("./QuesGen/static/"+U.Question[i].QI) #image
        im = Image.open(imm).size
        ww=im[0]
        hh=im[1]
        pdf.image(imm,None,None,ww//5,hh//5)   #

        pdf.set_font("Arial",size=10)
        a=U.ans[i]-1
        aa=U.actans[i]-1
        ll=[U.Question[i].OA,   U.Question[i].OB,     U.Question[i].OC,     U.Question[i].OD]
        for j in range(len(ll)):
            pdf.set_text_color(0,0,0)    
            if a==-1:
                pdf.cell(190, 10, txt = str(j+1)+") "+str(ll[j]), ln = 2, align = 'L') 
                continue
            if j==a:
                pdf.set_text_color(150,0,0)  
            if j==aa:
                pdf.set_text_color(0,150,0)     
            pdf.cell(190, 10, txt = str(j+1)+") "+str(ll[j]), ln = 2, align = 'L') 
        
        pdf.cell(190, 10, txt = "_______________________________________________________________________________________________", ln = 1, align = 'L') 


    f='./QuesGen/static/User/'+str(id)+'/Certificate.pdf'
    pdf.output(f)
    
    return render(request,'end.html',{'path':'/User/'+str(id)+'/Certificate.pdf'})



def play(request,id,opt):
    U=CU.UL[id]
    q=U.getQ()
    data={
    'id':U.id,
    'uname':U.name,    
    'QN': q.QN,
    'Q': q.Q,
    'OA':q.OA,
    'OB':q.OB,
    'OC':q.OC,
    'OD':q.OD,
    'img':q.QI
    }
    if opt is not None:
        U.ans.append(opt)
    return render(request,'./Play.html',data)

def index(request):
    if request.method == 'POST':

        if(request.POST['form']=='reg'):
            U = User()
            U.name=request.POST['name']
            U.time=int(request.POST['time'])
            U.fintime=U.time
            U.ds=list(map(int,list(request.POST.keys())[4:]))
            CU(U)
            id=len(CU.UL)-1

            if not os.path.exists('./QuesGen/static/User/'+str(id)):
                os.makedirs('./QuesGen/static/User/'+str(id))

            return play(request,id,None)

        if str(request.POST['form'])[0]=='s':
            id=int(str(request.POST['form'])[1:])
            return submit(request,id,request.POST['time'])

        else :
            if 'opt' not in request.POST.keys():
                return play(request,int(request.POST['form']),0)
            return play(request,int(request.POST['form']),int(request.POST['opt']))



    return render(request,'index.html')


