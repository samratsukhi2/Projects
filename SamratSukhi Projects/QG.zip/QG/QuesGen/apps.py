from django.apps import AppConfig
from .datastructure import *



class QuesgenConfig(AppConfig):
    name = 'QuesGen'

class Question:
    def __init__(self,ql,id,num):
        self.QN=num
        di={1:Array(id,num),2:LinkedList(id,num),3:Stack(id,num),4:Queue(id,num),5:Tree(id,num),6:Graph(id,num)}
        DS= di[suffle(ql)[0]]
        DS=DS.Q()
        self.Q=DS.ques
        self.QI=DS.img
        self.ANS=DS.opt[0]

        sq=suffle(DS.opt)
        self.OA=sq[0]
        self.OB=sq[1]
        self.OC=sq[2]
        self.OD=sq[3]

        for i in range(len(sq)):
            if self.ANS==sq[i]:
                self.ANS=i+1     

        self.gans=[]

        


class User:
    def __init__(self):
        self.id=0
        self.name=''
        self.time=[0,10,0]
        self.fintime=0
        self.ds=[]
        self.Question=[]
        self.actans=[]
        self.ans=[]

    def getQ(self):
        Q=Question(self.ds,self.id,len(self.Question)+1)
        self.actans.append(Q.ANS)
        self.Question.append(Q)
        return Q
        

class CU:
    UL=[]
    def __init__(self,U):
        U.id=len(self.UL)
        self.UL.append(U)
        


