
import random
from PIL import Image
from PIL import ImageDraw,ImageColor,ImageFont
from binarytree  import *
from networkx.generators.random_graphs import erdos_renyi_graph

color=['red','blue','green','magenta','yellow','black','orange','violet']#list(ImageColor.colormap.items())

def rand(n,x):
    return random.randint(n, x)

def suffle(x):
    random.shuffle(x)
    return  x
def randbool():
    return bool(random.getrandbits(1))

class QStruct:
    def __init__(self):
        self.ques=''
        self.opt=''
        self.img=''
class Graph:
    def aimg(self,g,name):
        w=500
        h=500
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)
        np=[]
        for i in g.nodes:
            x=rand(20,w-20)
            y=rand(20,h-20)
            np.append((x,y))
            
        for i in g.edges:
            a,b=np[i[0]]
            a=a+10
            b=b+10
            c,d=np[i[1]]
            c=c-10
            d=d-10
            draw.line([(a,b), (c,d)],fill ='green',width=3) #color[rand(0,len(color)-1)]

        for i in g.nodes:
            x,y=np[i]
            draw.ellipse([(x-15,y-15),(x+20,y+20 )],fill='red' )
            draw.text((x-5, y-10),str(i),fill='blue',font=ImageFont.truetype("arial.ttf", 20))
        im.save(name)

    def q1(self):
        g = erdos_renyi_graph(rand(5,10),0.3)
    
        self.n.ques='count the number of nodes from the following graph.'
        ans=[]
        ans.append(len(g.nodes))
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        self.aimg(g,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")


        i=0
        while(len(ans)!=4):
            res=rand(ans[0]-10,ans[0]+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans

    def q2(self):
        g = erdos_renyi_graph(rand(5,10),0.3)
    
        self.n.ques='count the number of edges from the following graph.'
        ans=[]
        ans.append(len(g.edges))
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        self.aimg(g,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(ans[0]-10,ans[0]+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans

    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()


    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        return self.n
class Tree:
    def aimg(self,t,name):
        c=0
        m=0
        for i in str(t):
            c+=1
            if i=='\n':
                if m < c:
                    m=c
                c=0
        w=m*6
        h=t.height*50
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)
        draw.text((0, 0),str(t),fill='blue')
        im.save(name)

    def q1(self):
        t=tree(height=rand(3,5))
        self.n.ques='select the correct height of the following tree.'
        ans=[]
        ans.append(int(t.height))
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        self.aimg(t,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")


        i=0
        while(len(ans)!=4):
            res=rand(ans[0]-10,ans[0]+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans

    def q2(self):
        t=tree(height=rand(3,5))
        self.n.ques='select the maximum node value in the following tree.'
        ans=[]
        ans.append(int(t.max_node_value))
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        self.aimg(t,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")


        i=0
        while(len(ans)!=4):
            res=rand(ans[0]-10,ans[0]+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans

    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()


    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        return self.n

class Queue:
    def aimg(self,a,name):
        w=50*len(a)
        h=130
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)

        draw.line([(0, 0), (w , 0)] , fill ="red", width = 5) 
        draw.line([(0, 100), (w , 100)] , fill ="red", width = 3) 
        ele=0
        for i in range(len(a)):
            draw.text((ele+6, 50), str(a[i]),fill='blue')
            ele=ele+50
            draw.line([(ele, 0), (ele , 100)] , fill ="red", width = 1) 
        draw.text((20, 120),'REAR --->',fill='blue')
        draw.text((ele-60, 120),'FRONT ---> ',fill='blue')
        im.save(name)
    def bimg(self,a,name):
        w=50*len(a)
        h=130
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)

        draw.line([(0, 0), (w , 0)] , fill ="red", width = 5) 
        draw.line([(0, 100), (w , 100)] , fill ="red", width = 3) 
        ele=0
        for i in range(len(a)):
            draw.text((ele+6, 50), 'P-'+str(a[i][0]),fill='blue')
            draw.text((ele+6, 60), '['+str(a[i][1])+']',fill='blue')
            ele=ele+50
            draw.line([(ele, 0), (ele , 100)] , fill ="red", width = 1) 
        draw.text((20, 120),'REAR --->',fill='blue')
        draw.text((ele-60, 120),'FRONT ---> ',fill='blue')
        im.save(name)

    def q1(self):
        A=[]
        size=rand(6,20)
        for i in range(size):
            A.append(rand(0,1000))
        ind=rand(1,size-1)
        self.n.ques='select the element getting after '+str(ind)+'th DEQUEUE() from the given Queue. '
        ans=[]
        ans.append(A[-ind])

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(A,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(0,size-1)
            if A[res] not in ans:
                ans.append(A[res])
        
        self.n.opt=ans

    def q2(self):
        A=[]
        size=rand(10,20)
        r=0
        for i in range(size+1):
            r=rand(0,1000)
            if r not in A and i!=size:
                A.append((r,rand(1,15)))
        self.n.ques='which process will execute next Process[Priority]'
        ans=[]

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        self.bimg(A,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        A.sort(key=lambda x:x[1])

        ans.append(A[-1][0])
        i=0
        while(len(ans)!=4):
            res=rand(0,size-1)
            if A[res][0] not in ans:
                ans.append(A[res][0])
        
        self.n.opt=ans


    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()


    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        return self.n


class Stack:
    def eq(self):
        n=rand(5,15)
        exp=[]
        op=['+','-','*','/']
        exp.append(round(random.uniform(1,100),2))
        while(len(exp)<n):
            exp.append(round(random.uniform(1,100),2))
            exp.append(op[rand(0,3)])
        return exp
    def eval(self,l):
        s=[]
        ans=0
        for i in l:
            try :  
                float(i) 
                s.append(i)
            except : 
                b=s.pop()
                a=s.pop()
                if i =='+':
                    ans=a+b
                if i =='-':
                    ans=a-b
                if i =='*':
                    ans=a*b
                if i =='/':
                    ans=a/b
                s.append(ans)

        return s[0]

    def bimg(self,t,name):
        w=len(t)*10
        h=50
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)
        draw.text((10,10),t ,fill='blue',font=ImageFont.truetype("arial.ttf", 20))
        im.save(name)

    def aimg(self,a,name,t=True):
        a.reverse()
        w=500
        h=31*len(a)
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)
        y=0
        if t:
            draw.text((120,y+10),' T O P >>> ' ,fill='red')

        for i in range(len(a)):
            draw.text((250-len(str(a[i])*3),y+10),str(a[i]) ,fill='blue')
            y=y+30
            draw.line([(200,y), (300,y)],fill ="red",width=3)
        draw.line([(200,0), (200,y)],fill ="red",width=3)
        draw.line([(300,0), (300,y)],fill ="red",width=3)
        im.save(name)

    def q1(self):
        a=[]
        size=rand(6,15)
        for i in range(size):
            a.append(rand(0,1000))
        
        self.n.ques=' Choose the element top of the given stack.'
        ans=[]
        ans.append(a[-1])

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(a,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg",False)

        i=0
        while(len(ans)!=4):
            res=rand(0,size-1)
            if a[res] not in ans:
                ans.append(a[res])
        
        self.n.opt=ans
    
    def q2(self):
        e=self.eq()
        s=''
        for i in e:
            s+=str(i)+' '
        self.n.ques='Evaluate the following POSTFIX equation.'
        ans=[]
        a=self.eval(e)
        ans.append(a)
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg" 
        self.bimg(s,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")
        i=0
        while(len(ans)<4):
            b=random.uniform(a/10,a*10)    
            if b not in ans:
                ans.append(b)
        self.n.opt=ans

    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()

    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        return self.n
    

class LinkedList:
    class LL:
        def __init__(self,v):
            self.val=v
            self.next=None

    def count(self,ll):
        head=ll
        c=0
        while head!=None:
            c=c+1
            head=head.next
        return c
        
    def aimg(self,a,name):
        c=self.count(a)
        w=70*c
        h=35*c
        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)
        x,y=5,0
        head=a
        j=0
        for i in range(c):
            draw.rectangle([(x-5,y+5), (x+40,y+30)],outline='red')
            draw.rectangle([(x-5,y+5), (x+50,y+30)],outline='red')
            draw.line([(x+45,y+15), (x+70 ,y+15)] , fill ="red", width = 3) 
            draw.line([(x+70 ,y+15),(x+70,y+30)] , fill ="red", width = 3) 
            draw.ellipse((x+68,y+28,x+72,y+32), outline ='red')
            draw.text((x+5,y+13), str(head.val),fill='blue')
            head=head.next
            x,y=x+60,y+30
            j+=1
        draw.text((x+15,y+10), "(Null)",fill='blue')
        im.save(name)

    def q1(self):
        L=self.LL(rand(0,1000))
        cur=L
        size=rand(6,15)
        temp=None
        for i in range(size):
            temp=self.LL(rand(0,1000))
            cur.next=temp
            cur=cur.next
        
        self.n.ques='Count the number of elements in given Linked List.'
        ans=[]
        ans.append(self.count(L))

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(L,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(ans[0]-10,ans[0]+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans
    
    def q2(self):
        L=self.LL(rand(0,1000))
        cur=L
        size=rand(6,15)
        temp=None
        a=[]
        while(len(a)!=size):
            v=rand(0,1000)
            if v in a:
                continue
            a.append(v)
            temp=self.LL(v)
            cur.next=temp
            cur=cur.next
        
        ind=rand(0,size-2)
        self.n.ques='Which Node is just after the value '+str(a[ind])+'.'
        ans=[]
        ans.append(a[ind+1])

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(L,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(0,size-1)
            if a[res] not in ans:
                ans.append(a[res])
        
        self.n.opt=ans
    def Reverse(self,lst): 
        return [ele for ele in reversed(lst)] 
    def q3(self):
        L=self.LL(rand(0,1000))
        cur=L
        size=rand(6,15)
        temp=None
        a=[L.val]
        while(len(a)!=size):
            v=rand(0,1000)
            if v in a:
                continue
            a.append(v)
            temp=self.LL(v)
            cur.next=temp
            cur=cur.next
        
        
        self.n.ques='choose the reverse of the following linked list.'
        ans=[]
        ans.append(str(self.Reverse(a)))
        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(L,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=str(suffle(a))
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans

    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()

    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        else :
            self.q3()
        return self.n


class Array:
    def aimg(self,a,name):
        w=800
        h=100

        im = Image.new("RGB", (w, h), "#fff")
        draw = ImageDraw.Draw(im)

        draw.line([(0, 0), (w , 0)] , fill ="red", width = 5) 
        draw.line([(0, 100), (w , 100)] , fill ="red", width = 5) 
        draw.line([(0, 0), (0 , 100)] , fill ="red", width = 1) 
        ele=0
        for i in range(len(a)):
            draw.text((ele+6, 50), str(a[i]),fill='blue')
            ele=ele+w/len(a)
            draw.line([(ele, 0), (ele , 100)] , fill ="red", width = 1) 

        draw.line([(w-1,0), (w-1 , 100)] , fill ="red", width = 1) 
        im.save(name)

    def q1(self):
        A=[]
        size=rand(6,20)
        for i in range(size):
            A.append(rand(0,1000))

        ind=rand(0,size-1)
        self.n.ques='Choose the value of Given Array at index '+ str(ind) 
        ans=[]
        ans.append(A[ind])

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(A,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(0,size-1)
            if A[res] not in ans:
                ans.append(A[res])
        
        self.n.opt=ans

    def q2(self):
        A=[]
        size=rand(10,20)
        for i in range(size):
            A.append(rand(-1000,1000))

        AA=sorted(A)
        ind=0
        for i in range(len(AA)):
            if A[i]!=AA[i]:
                ind=ind+1
        self.n.ques='How many elements are not at there proper index in given array (Assume if it is sorted in inreament order).'
        ans=[]
        ans.append(ind)

        self.n.img='User/'+str(self.id)+"/"+str(self.qn)+".jpg"
        
        self.aimg(A,'./QuesGen/static/User/'+str(self.id)+"/"+str(self.qn)+".jpg")

        i=0
        while(len(ans)!=4):
            res=rand(ind-10,ind+10)
            if res not in ans:
                ans.append(res)
        
        self.n.opt=ans


    def __init__(self,id,qn):
        self.id=id
        self.qn=qn
        self.img=''
        self.n= QStruct()


    def Q(self):
        i=rand(0,1)
        if i==0:
            self.q1()
        if i==1:
            self.q2()
        return self.n




